<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <title>Document</title>
</head>
<body>
    <h1>Adivina el numero secreto</h1>
    <?php if(session()->has('mensaje')): ?>
        <p><?php echo e(session('mensaje')); ?></p>
    <?php endif; ?>
    <?php if(session('tries')>0): ?>
        <form action="<?php echo e(url('/numero')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="number">Adivina el numero secreto</label>
            <input type="number" name="number" id="number" min="1" max="1000" required>
            <button type="submit">Adivinar</button>
        </form><br>
    <?php endif; ?>
    <a href="<?php echo e(url('/gameOver')); ?>">Jugar de nuevo</a>
</body>
</html><?php /**PATH /var/www/html/resources/views/numero.blade.php ENDPATH**/ ?>